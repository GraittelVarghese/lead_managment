from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(state)
admin.site.register(district)
admin.site.register(qualification)
admin.site.register(enquirysource)
admin.site.register(followupstatus)
admin.site.register(syllabus)
admin.site.register(course)
admin.site.register(branch)
admin.site.register(student)